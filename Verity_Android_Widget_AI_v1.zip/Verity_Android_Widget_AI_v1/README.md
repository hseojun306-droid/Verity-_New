# Verity™ Android — 포스트잇 홈 화면 위젯 + AI 음성대화

PC 없이 AndroidIDE 같은 모바일 Android 개발환경에서 열어 APK를 빌드할 수 있는 프로젝트입니다.

## 포함 기능
- 홈 화면에 올릴 수 있는 베리티™ 포스트잇 위젯
- 위젯 안에 베리티™ 얼굴 표시
- 위젯을 누르면 앱이 열리고 음성 인식을 바로 시작
- 텍스트/음성으로 Verity 서버의 `/api/chat`에 질문
- Android TTS로 답변을 읽어줌
- 앱 안의 `음성녹음` 안내 기능

## 중요한 설정
`app/src/main/java/com/verity/app/MainActivity.java`에서 아래 주소를 실제 Verity 웹 서버 주소로 바꿔주세요.

```java
static final String SERVER_URL = "https://YOUR-VERITY-SERVER.onrender.com";
```

예: Render에 실제 배포된 주소가 `https://example.onrender.com`이면 그 주소를 넣습니다.

API 키는 APK 안에 넣지 않습니다. OpenAI API 키는 Verity 서버의 환경변수에만 둡니다.

## 모바일 빌드 순서
1. ZIP 압축을 풉니다.
2. AndroidIDE에서 압축을 푼 `Verity_Android_Widget_AI_v1` 폴더를 엽니다.
3. Gradle Sync가 끝날 때까지 기다립니다.
4. `SERVER_URL`을 실제 서버 주소로 수정합니다.
5. Build APK를 실행합니다.
6. APK를 휴대폰에 설치합니다.
7. 홈 화면 빈 곳을 길게 누릅니다 → 위젯 → Verity™ → 포스트잇 위젯을 추가합니다.

위젯은 Android의 AppWidgetProvider 방식으로 홈 화면에 게시됩니다.
